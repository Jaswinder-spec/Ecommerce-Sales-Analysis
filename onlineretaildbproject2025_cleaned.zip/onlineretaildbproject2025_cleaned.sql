select * from dbo.onlineretail;
DELETE FROM dbo.OnlineRetail WHERE Quantity < 0;
SELECT Country, ROUND(SUM(UnitPrice * Quantity), 2) AS TotalSales
FROM dbo.onlineretail
GROUP BY Country
ORDER BY TotalSales DESC;
select top 10  description, sum(quantity) as totalquantity
from  dbo.OnlineRetail
group by description
order by totalquantity desc
;
select top 10  CustomerID, sum(quantity *  UnitPrice) as TotalSpending
from dbo.OnlineRetail
group by CustomerID
order by TotalSpending desc
;
select * from dbo.OnlineRetail;
SELECT YEAR(InvoiceDate) AS Year, MONTH(InvoiceDate) AS Month,
SUM(Quantity * UnitPrice) AS MonthlyRevenue
FROM dbo.OnlineRetail
GROUP BY YEAR(InvoiceDate), MONTH(InvoiceDate)
ORDER BY Year, Month;
SELECT CustomerID,
SUM(Quantity * UnitPrice) AS TotalSpend
FROM dbo.OnlineRetail
GROUP BY CustomerID
ORDER BY TotalSpend DESC;
SELECT CustomerID, COUNT(DISTINCT InvoiceNo) AS NumberOfOrders
FROM dbo.OnlineRetail
GROUP BY CustomerID
ORDER BY NumberOfOrders DESC;
SELECT CustomerID,
AVG(Quantity * UnitPrice) AS AvgOrderValue
FROM dbo.OnlineRetail
GROUP BY CustomerID
ORDER BY AvgOrderValue DESC;
SELECT CustomerID,
MAX(InvoiceDate) AS LastPurchaseDate,
DATEDIFF(DAY, MAX(InvoiceDate), GETDATE()) AS DaysSinceLastPurchase
FROM dbo.OnlineRetail
GROUP BY CustomerID
ORDER BY DaysSinceLastPurchase;
SELECT CustomerID, COUNT(DISTINCT InvoiceNo) AS Frequency
FROM dbo.OnlineRetail
GROUP BY CustomerID
ORDER BY Frequency DESC;
-^-This shows how often each customer places an order.
-C-Monetary: How much has the customer spent?
SELECT CustomerID,
SUM(Quantity * UnitPrice) AS TotalSpend
FROM dbo.OnlineRetail
GROUP BY CustomerID
ORDER BY TotalSpend DESC;
WITH RFM AS (
SELECT CustomerID,
DATEDIFF(DAY, MAX(InvoiceDate), GETDATE()) AS Recency,
COUNT(DISTINCT InvoiceNo) AS Frequency,
SUM(Quantity * UnitPrice) AS Monetary
FROM dbo.onlineRetail
GROUP BY CustomerID
)
SELECT CustomerID,
Recency,
Frequency,
Monetary,
CASE
WHEN Recency <= 30 AND Frequency >= 5 AND Monetary >= 1000 THEN 'High Value'
WHEN Recency > 30 AND Frequency <= 2 AND Monetary <= 100 THEN 'Churning'
ELSE 'Potential'
END AS CustomerSegment
FROM RFM
ORDER BY CustomerID;
SELECT CustomerID, StockCode, Description, SUM(Quantity) AS TotalQuantity
FROM dbo.OnlineRetail
GROUP BY CustomerID, StockCode, Description
ORDER BY TotalQuantity DESC;
SELECT YEAR(InvoiceDate) AS Year, MONTH(InvoiceDate) AS Month,
COUNT(DISTINCT InvoiceNo) AS NumberOfOrders,
SUM(Quantity * UnitPrice) AS TotalSales
FROM dbo.OnlineRetail
GROUP BY YEAR(InvoiceDate), MONTH(InvoiceDate)
ORDER BY Year, Month;
SELECT CustomerID, COUNT(DISTINCT InvoiceNo) AS RepeatPurchases
FROM dbo.onlineRetail
GROUP BY CustomerID
HAVING COUNT(DISTINCT InvoiceNo) > 1
ORDER BY RepeatPurchases DESC;