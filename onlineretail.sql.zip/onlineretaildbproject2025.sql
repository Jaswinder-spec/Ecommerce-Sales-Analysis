select * from dbo.onlineretail;

--remove negative values--
DELETE FROM dbo.OnlineRetail WHERE Quantity < 0;

--Performing Data Analysis here--

--Total Sales Per Country--
SELECT Country, ROUND(SUM(UnitPrice * Quantity), 2) AS TotalSales
FROM dbo.onlineretail
GROUP BY Country
ORDER BY TotalSales DESC;

--Top 10 Selling Products--
select top 10  description, sum(quantity) as totalquantity
from  dbo.OnlineRetail
group by description
order by totalquantity desc
;
--Customer Segmentation--
select top 10  CustomerID, sum(quantity *  UnitPrice) as TotalSpending
from dbo.OnlineRetail 
group by CustomerID
order by TotalSpending desc
;
select * from dbo.OnlineRetail;

-- Monthly Revenue Trend--
SELECT YEAR(InvoiceDate) AS Year, MONTH(InvoiceDate) AS Month, 
       SUM(Quantity * UnitPrice) AS MonthlyRevenue
FROM dbo.OnlineRetail
GROUP BY YEAR(InvoiceDate), MONTH(InvoiceDate)
ORDER BY Year, Month;

--Total Purchase Per Customer--
SELECT CustomerID,
       SUM(Quantity * UnitPrice) AS TotalSpend
FROM dbo.OnlineRetail
GROUP BY CustomerID
ORDER BY TotalSpend DESC;

--Number of orders per customer--
SELECT CustomerID, COUNT(DISTINCT InvoiceNo) AS NumberOfOrders
FROM dbo.OnlineRetail
GROUP BY CustomerID
ORDER BY NumberOfOrders DESC;


-- Average Order Value --
SELECT CustomerID,
       AVG(Quantity * UnitPrice) AS AvgOrderValue
FROM dbo.OnlineRetail
GROUP BY CustomerID
ORDER BY AvgOrderValue DESC;
--Recency, Frequency, and Monetary (RFM) Analysis--

--A-Recency: How recently did the customer purchase?

SELECT CustomerID,
       MAX(InvoiceDate) AS LastPurchaseDate,
       DATEDIFF(DAY, MAX(InvoiceDate), GETDATE()) AS DaysSinceLastPurchase
FROM dbo.OnlineRetail
GROUP BY CustomerID
ORDER BY DaysSinceLastPurchase;
--This query calculates how long it's been since each customer last made a purchase.--
--B-Frequency: How often does the customer purchase?--

SELECT CustomerID, COUNT(DISTINCT InvoiceNo) AS Frequency
FROM dbo.OnlineRetail
GROUP BY CustomerID
ORDER BY Frequency DESC;
--^-This shows how often each customer places an order.

--C-Monetary: How much has the customer spent?
SELECT CustomerID,
       SUM(Quantity * UnitPrice) AS TotalSpend
FROM dbo.OnlineRetail
GROUP BY CustomerID
ORDER BY TotalSpend DESC;
--^This shows the total spending per customer.

--Segment Customers Based on RFM--
WITH RFM AS (
    SELECT CustomerID,
           DATEDIFF(DAY, MAX(InvoiceDate), GETDATE()) AS Recency,
           COUNT(DISTINCT InvoiceNo) AS Frequency,
           SUM(Quantity * UnitPrice) AS Monetary
    FROM dbo.onlineRetail
    GROUP BY CustomerID
)
SELECT CustomerID,
       Recency,
       Frequency,
       Monetary,
       CASE
           WHEN Recency <= 30 AND Frequency >= 5 AND Monetary >= 1000 THEN 'High Value'
           WHEN Recency > 30 AND Frequency <= 2 AND Monetary <= 100 THEN 'Churning'
           ELSE 'Potential'
       END AS CustomerSegment
FROM RFM
ORDER BY CustomerID;

-- Above All will show  categories of customers like high ,churning, potential customers
--High-Value Customers: Recent, frequent, and high spenders.
--Churning Customers: Customers who haven�t purchased recently.
--Potential Customers: Customers who buy frequently but with low monetary value.

--Top-Selling Products per Customer--

SELECT CustomerID, StockCode, Description, SUM(Quantity) AS TotalQuantity
FROM dbo.OnlineRetail
GROUP BY CustomerID, StockCode, Description
ORDER BY TotalQuantity DESC;

--Seasonality Analysis (Monthly/Yearly Trends)--

SELECT YEAR(InvoiceDate) AS Year, MONTH(InvoiceDate) AS Month,
       COUNT(DISTINCT InvoiceNo) AS NumberOfOrders,
       SUM(Quantity * UnitPrice) AS TotalSales
FROM dbo.OnlineRetail
GROUP BY YEAR(InvoiceDate), MONTH(InvoiceDate)
ORDER BY Year, Month;

 --Identifying Repeat Customers--
 SELECT CustomerID, COUNT(DISTINCT InvoiceNo) AS RepeatPurchases
FROM dbo.onlineRetail
GROUP BY CustomerID
HAVING COUNT(DISTINCT InvoiceNo) > 1
ORDER BY RepeatPurchases DESC;



  
















    






